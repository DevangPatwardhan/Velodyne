#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
import open3d as o3d
import numpy as np

# Sensor location
SENSOR_LOCATION = np.array([0.0, 0.0, 0.381047])

def pointcloud_callback(msg):
    # Convert PointCloud2 message to numpy array
    points = np.array(list(pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))))

    # Check if points are available
    if len(points) == 0:
        rospy.logwarn("No points received")
        return

    # Convert numpy array to Open3D point cloud
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points[:, :3])

    # Downsample point cloud for faster processing
    pcd = pcd.voxel_down_sample(voxel_size=0.1)

    # Segment planes using RANSAC (optional, can be skipped if not needed)
    plane_model, inliers = pcd.segment_plane(distance_threshold=0.05, ransac_n=3, num_iterations=1000)
    remaining_cloud = pcd.select_by_index(inliers, invert=True)

    # Cluster the remaining points using DBSCAN
    labels = np.array(remaining_cloud.cluster_dbscan(eps=0.2, min_points=10))

    # Number of clusters (obstacles) detected
    num_obstacles = len(set(labels)) - (1 if -1 in labels else 0)
    rospy.loginfo("Number of obstacles detected: %d" % num_obstacles)

    closest_point = None
    min_distance = float('inf')

    # Identify and get details of each obstacle
    for i in range(num_obstacles):
        cluster_indices = np.where(labels == i)[0]
        cluster_points = remaining_cloud.select_by_index(cluster_indices)
        
        # Calculate bounding box for the cluster
        bbox = cluster_points.get_axis_aligned_bounding_box()
        extents = bbox.get_extent()
        center = bbox.get_center()

        # Find the closest point in this cluster to the sensor
        cluster_array = np.asarray(cluster_points.points)
        distances = np.linalg.norm(cluster_array - SENSOR_LOCATION, axis=1)
        min_cluster_distance = np.min(distances)
        closest_cluster_point = cluster_array[np.argmin(distances)]

        # Check if this is the closest point overall
        if min_cluster_distance < min_distance:
            min_distance = min_cluster_distance
            closest_point = closest_cluster_point

        # Log the details
        rospy.loginfo(f"Obstacle {i + 1}: Center at {center}, Dimensions {extents}")
        rospy.loginfo(f"Obstacle {i + 1}: Closest point {closest_cluster_point} at distance {min_cluster_distance}")

    if closest_point is not None:
        x_dist = closest_point[0] - SENSOR_LOCATION[0]
        y_dist = closest_point[1] - SENSOR_LOCATION[1]
        z_dist = closest_point[2] - SENSOR_LOCATION[2]
        rospy.loginfo(f"Closest point to sensor: {closest_point} with distances x: {x_dist}, y: {y_dist}, z: {z_dist}")

def main():
    rospy.init_node("obstacle_detection_node", anonymous=True)
    rospy.Subscriber("/velodyne_points2", PointCloud2, pointcloud_callback)
    rospy.spin()

if __name__ == "__main__":
    main()

