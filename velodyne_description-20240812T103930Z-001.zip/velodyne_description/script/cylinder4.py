#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
import open3d as o3d
import numpy as np
import tf

def pointcloud_callback(msg):
    # Convert PointCloud2 message to numpy array
    points = np.array(list(pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))))

    # Check if points are available
    if len(points) == 0:
        rospy.logwarn("No points received")
        return

    # Convert numpy array to Open3D point cloud
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points[:, :3])

    # Downsample point cloud for faster processing
    pcd = pcd.voxel_down_sample(voxel_size=0.1)

    # Segment planes using RANSAC (optional, can be skipped if not needed)
    plane_model, inliers = pcd.segment_plane(distance_threshold=0.05, ransac_n=3, num_iterations=1000)
    remaining_cloud = pcd.select_by_index(inliers, invert=True)

    # Cluster the remaining points using DBSCAN
    labels = np.array(remaining_cloud.cluster_dbscan(eps=0.2, min_points=10))

    # Number of clusters (obstacles) detected
    num_obstacles = len(set(labels)) - (1 if -1 in labels else 0)
    rospy.loginfo("Number of obstacles detected: %d" % num_obstacles)

    # Initialize tf listener
    listener = tf.TransformListener()

    # Identify and get details of each obstacle
    for i in range(num_obstacles):
        cluster_indices = np.where(labels == i)[0]
        cluster_points = remaining_cloud.select_by_index(cluster_indices)

        # Calculate bounding box for the cluster
        bbox = cluster_points.get_axis_aligned_bounding_box()
        extents = bbox.get_extent()
        center = bbox.get_center()

        # Transform the center to the world frame
        try:
            listener.waitForTransform('/world', msg.header.frame_id, rospy.Time(0), rospy.Duration(4.0))
            (trans, rot) = listener.lookupTransform('/world', msg.header.frame_id, rospy.Time(0))
            center_world = listener.transformPoint('/world', center)
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            rospy.logwarn("TF transformation failed")
            center_world = center  # Use the original center if transformation fails

        # Log the details
        rospy.loginfo(f"Obstacle {i + 1}: Center at {center_world}, Dimensions {extents}")

def main():
    rospy.init_node("obstacle_detection_node", anonymous=True)
    rospy.Subscriber("/velodyne_points2", PointCloud2, pointcloud_callback)
    rospy.spin()

if __name__ == "__main__":
    main()

