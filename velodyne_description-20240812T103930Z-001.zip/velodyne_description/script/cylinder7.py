#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
import open3d as o3d
import numpy as np
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point

# Sensor location
SENSOR_LOCATION = np.array([0.0, 0.0, 0.381047])

class ObstacleDetection:
    def __init__(self):
        self.marker_pub = rospy.Publisher("visualization_marker", Marker, queue_size=10)
        rospy.Subscriber("/velodyne_points2", PointCloud2, self.pointcloud_callback)

    def pointcloud_callback(self, msg):
        points = np.array(list(pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))))

        if len(points) == 0:
            rospy.logwarn("No points received")
            return

        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points[:, :3])
        pcd = pcd.voxel_down_sample(voxel_size=0.1)

        plane_model, inliers = pcd.segment_plane(distance_threshold=0.05, ransac_n=3, num_iterations=1000)
        remaining_cloud = pcd.select_by_index(inliers, invert=True)
        labels = np.array(remaining_cloud.cluster_dbscan(eps=0.2, min_points=10))

        num_obstacles = len(set(labels)) - (1 if -1 in labels else 0)
        rospy.loginfo("Number of obstacles detected: %d" % num_obstacles)

        obstacles = []
        for i in range(num_obstacles):
            cluster_indices = np.where(labels == i)[0]
            cluster_points = remaining_cloud.select_by_index(cluster_indices)

            cluster_array = np.asarray(cluster_points.points)
            distances = np.linalg.norm(cluster_array - SENSOR_LOCATION, axis=1)
            min_cluster_distance = np.min(distances)
            closest_cluster_point = cluster_array[np.argmin(distances)]

            obstacles.append((min_cluster_distance, closest_cluster_point))

        obstacles.sort(key=lambda x: x[0])
        for idx, (dist, point) in enumerate(obstacles):
            x_dist, y_dist, z_dist = point - SENSOR_LOCATION
            rospy.loginfo(f"Obstacle {idx + 1}: Closest point {point} with distances x: {x_dist}, y: {y_dist}, z: {z_dist}")

            self.publish_single_point(point)

    def publish_single_point(self, point3):
        marker = Marker()
        marker.header.frame_id = "base_link"
        marker.header.stamp = rospy.Time.now()
        marker.ns = "obstacles"
        marker.id = 0
        marker.type = Marker.POINTS
        marker.action = Marker.ADD
        marker.pose.orientation.w = 1.0
        marker.scale.x = 0.1
        marker.scale.y = 0.1
        marker.color.g = 1.0
        marker.color.a = 1.0

        point_msg = Point()
        point_msg.x = point3[0]
        point_msg.y = point3[1]
        point_msg.z = point3[2]
        marker.points.append(point_msg)

        self.marker_pub.publish(marker)

if __name__ == "__main__":
    rospy.init_node("obstacle_detection_node", anonymous=True)
    detector = ObstacleDetection()
    rospy.spin()

