#!/usr/bin/env python3
import rospy
import sensor_msgs.point_cloud2 as pc2
import math

class PointCloudProcessor:
    def __init__(self):
        rospy.init_node('point_cloud_processor')
        rospy.Subscriber("/velodyne_points2", pc2.PointCloud2, self.point_cloud_callback)
        rospy.spin()

    def point_cloud_callback(self, msg):
        min_x, max_x = float('inf'), float('-inf')  # Initialize min and max values for x dimension
        min_y, max_y = float('inf'), float('-inf')  # Initialize min and max values for y dimension
        min_z, max_z = float('inf'), float('-inf')  # Initialize min and max values for z dimension
        min_distance = float('inf')  # Initialize min_distance

        points = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)
        for point in points:
            x, y, z = point
            # Filter out points close to the ground (within 10 cm above z-axis)
            if z > 0.1:
                # Update min and max values for each dimension
                min_x = min(min_x, x)
                max_x = max(max_x, x)
                min_y = min(min_y, y)
                max_y = max(max_y, y)
                min_z = min(min_z, z)
                max_z = max(max_z, z)
                # Calculate the distance of the point from the origin
                distance = math.sqrt(x**2 + y**2 + z**2)
                min_distance = min(min_distance, distance)

        # Print the detected range in each dimension and the minimum distance
        print("Detected range in x dimension:", min_x, "to", max_x)
        print("Detected range in y dimension:", min_y, "to", max_y)
        print("Detected range in z dimension:", min_z, "to", max_z)
        print("Minimum distance of obstacle:", min_distance)

if __name__ == "__main__":
    try:
        processor = PointCloudProcessor()
    except rospy.ROSInterruptException:
        pass

