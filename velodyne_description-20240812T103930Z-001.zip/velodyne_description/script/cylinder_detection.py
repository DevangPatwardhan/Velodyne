#!/usr/bin/env python3



import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
import open3d as o3d
import numpy as np

def pointcloud_callback(msg):
    # Convert PointCloud2 message to numpy array
    points = np.array(list(pc2.read_points(msg, skip_nans=True)))

    # Extract x, y, z coordinates
    points_xyz = points[:, :3]

    # Convert numpy array to Open3D point cloud
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points_xyz)

    # Estimate normals
    pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))

    # Segment shapes using RANSAC plane detection
    plane_model, inliers = pcd.segment_plane(distance_threshold=0.1, ransac_n=3, num_iterations=1000)

    # Extract shape clusters using DBSCAN clustering
    labels = np.array(pcd.cluster_dbscan(eps=0.2, min_points=10, print_progress=False))

    # Print the number of detected shapes
    num_shapes = np.max(labels) + 1
    rospy.loginfo("Number of shapes detected: %d" % num_shapes)

def main():
    rospy.init_node("shape_detection_node", anonymous=True)
    rospy.Subscriber("/velodyne_points2", PointCloud2, pointcloud_callback)
    rospy.spin()

if __name__ == "__main__":
    main()

