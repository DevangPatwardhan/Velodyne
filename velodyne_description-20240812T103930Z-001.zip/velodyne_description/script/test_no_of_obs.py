#!/usr/bin/env python3

import rospy
import sensor_msgs.point_cloud2 as pc2
import math
import pcl

class PointCloudProcessor:
    def __init__(self):
        rospy.init_node('point_cloud_processor')
        rospy.Subscriber("/velodyne_points2", pc2.PointCloud2, self.point_cloud_callback)
        rospy.spin()

    def point_cloud_callback(self, msg):
        cloud = pcl.PointCloud()  # Create a new point cloud
        points = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)

        # Convert generator to point cloud directly
        cloud.from_generator(points, count=-1, fields=["x", "y", "z"])

        seg = cloud.make_segmenter()
        seg.set_model_type(pcl.SACMODEL_PLANE)
        seg.set_method_type(pcl.SAC_RANSAC)
        seg.set_distance_threshold(0.01)
        inliers, _ = seg.segment()

        cloud_filtered = cloud.extract(inliers, negative=True)

        tree = cloud_filtered.make_kdtree()
        ec = cloud_filtered.make_EuclideanClusterExtraction()
        ec.set_ClusterTolerance(0.02)
        ec.set_MinClusterSize(100)
        ec.set_MaxClusterSize(25000)
        ec.set_SearchMethod(tree)
        clusters = ec.Extract()

        num_boxes = len(clusters)
        print("Number of boxes detected:", num_boxes)

        for i, cluster in enumerate(clusters):
            # Calculate centroid of the cluster
            centroid = cluster.to_array().mean(axis=0)
            print("Box", i+1, "centroid:", centroid)

            # Calculate orientation of the box
            eigen_values, eigen_vectors = pcl.pcl.calculateCovarianceMatrix(cluster)
            idx = eigen_values.argsort()[::-1]
            eigen_vectors = eigen_vectors[:, idx]
            orientation = eigen_vectors[:, 0]  # First eigen vector gives the orientation
            print("Box", i+1, "orientation:", orientation)

if __name__ == "__main__":
    try:
        processor = PointCloudProcessor()
    except rospy.ROSInterruptException:
        pass

