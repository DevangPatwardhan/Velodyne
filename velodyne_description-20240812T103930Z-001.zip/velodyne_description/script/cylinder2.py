#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
import open3d as o3d
import numpy as np
from sklearn.cluster import DBSCAN

def pointcloud_callback(msg):
    # Convert PointCloud2 message to numpy array
    points = np.array(list(pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))))

    # Check if points are available
    if len(points) == 0:
        rospy.logwarn("No points received")
        return

    # Convert numpy array to Open3D point cloud
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points[:, :3])

    # Downsample point cloud for faster processing
    pcd = pcd.voxel_down_sample(voxel_size=0.1)

    # Estimate normals
    pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))

    # Segment planes using RANSAC
    plane_model, inliers = pcd.segment_plane(distance_threshold=0.05, ransac_n=3, num_iterations=1000)
    plane_cloud = pcd.select_by_index(inliers)
    remaining_cloud = pcd.select_by_index(inliers, invert=True)

    # Cluster the remaining points using DBSCAN
    labels = np.array(remaining_cloud.cluster_dbscan(eps=0.2, min_points=10))

    # Number of clusters (shapes) detected
    num_shapes = len(set(labels)) - (1 if -1 in labels else 0)
    rospy.loginfo("Number of shapes detected: %d" % num_shapes)

    # Identify and classify shapes
    for i in range(num_shapes):
        cluster_indices = np.where(labels == i)[0]
        cluster_points = remaining_cloud.select_by_index(cluster_indices)
        
        # Fit bounding box
        bbox = cluster_points.get_axis_aligned_bounding_box()

        # Classify shape based on bounding box dimensions
        extents = bbox.get_extent()
        if np.isclose(extents[0], extents[1]) and np.isclose(extents[1], extents[2]):
            shape_type = "sphere"
        elif np.isclose(extents[0], extents[1]) and extents[2] > extents[0]:
            shape_type = "cylinder"
        else:
            shape_type = "box"
        
        rospy.loginfo(f"Shape {i + 1}: {shape_type} with dimensions {extents}")

def main():
    rospy.init_node("shape_detection_node", anonymous=True)
    rospy.Subscriber("/velodyne_points2", PointCloud2, pointcloud_callback)
    rospy.spin()

if __name__ == "__main__":
    main()

